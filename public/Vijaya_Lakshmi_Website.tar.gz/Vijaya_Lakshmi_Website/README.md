# Vijaya Lakshmi Enterprises - Professional Website

A complete, production-ready website for Vijaya Lakshmi Enterprises, a leading supplier of industrial and pneumatic products in India.

## Project Overview

This is a professional, multi-page website built with pure HTML5, CSS3, and Vanilla JavaScript. The site features:

- **4 Main Pages**: Home, Products, About Us, and Contact
- **40 Deduplicated Products**: Sourced and consolidated from 7 reference industrial websites
- **Professional Design**: Light-themed website with dark maroon/burgundy (#5D1F2D) and gold accents
- **Fully Responsive**: Mobile-first design that works perfectly on all devices
- **Advanced Features**: Search, filtering, form validation, and animations

## File Structure

```
Vijaya_Lakshmi_Website/
├── index.html              # Homepage with hero section and categories
├── products.html           # Product catalog with search and filters
├── about.html              # Company information and mission
├── contact.html            # Contact form and business information
├── ve-logo.jpg             # Professional VE logo
├── assets/
│   ├── css/
│   │   └── style.css       # Complete styling (796 lines)
│   └── js/
│       ├── script.js       # Navigation and general functionality
│       ├── products.js     # Product data and filtering logic
│       └── contact.js      # Contact form handling
└── README.md              # This file
```

## Getting Started

### Option 1: Direct File Access
1. Extract the ZIP file to your desired location
2. Open `index.html` in any modern web browser
3. Navigate through all pages using the menu

### Option 2: Local Server (Recommended)
```bash
# Using Python 3
python -m http.server 8000

# Using Python 2
python -m SimpleHTTPServer 8000

# Using Node.js (if installed)
npx http-server
```

Then open `http://localhost:8000` in your browser.

## Features

### Homepage (index.html)
- Eye-catching hero section
- "Why Choose Us" feature cards
- Product categories showcase
- Call-to-action section
- Professional footer with contact info

### Products Page (products.html)
- **40 Deduplicated Products** across 6 categories:
  - Pneumatic Fittings (8 products)
  - Pipe Fittings (8 products)
  - Valves & Regulators (8 products)
  - Tubes & Hoses (7 products)
  - Asbestos/Non-Asbestos Sheets (6 products)
  - Additional Products (3 products)

- **Real-time Search**: Find products instantly
- **Category Filtering**: Browse by product type
- **Product Details**: Specifications, pricing, and descriptions

### About Us Page (about.html)
- Company mission and vision
- Complete product offerings list
- Why choose Vijaya Lakshmi
- Contact information

### Contact Page (contact.html)
- Professional contact form with:
  - Name, Email, Company (optional)
  - Phone (optional)
  - Product Interest dropdown
  - Message textarea
  - Privacy policy checkbox
- Business hours and location
- Services information

## Color Palette

- **Primary Maroon**: #5D1F2D (Main branding color)
- **Primary Dark**: #3D1218 (Hover states)
- **Primary Light**: #8B3A49 (Accents)
- **Accent Gold**: #C9A961 (Gold highlights)
- **Text Dark**: #2C2C2C (Main text)
- **Background Light**: #F9F8F6 (Light backgrounds)
- **White**: #FFFFFF (Primary background)

## Product Data

### Deduplication Process
Products were analyzed from 7 reference websites:
1. tu-lok.com
2. jindustrialproduct.in
3. kpsalesindia.com
4. psindustrialproduct.in
5. jayagenciez.com
6. excelmetal.net
7. panamengineers.com

All duplicate entries were merged into 40 unique products with accurate specifications and pricing ranges.

## Technical Details

### Browser Compatibility
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

### Performance
- No external CDN dependencies
- Optimized CSS and JavaScript
- Fast loading times
- Smooth animations and interactions

### Accessibility
- Semantic HTML structure
- Proper heading hierarchy
- Alt text for images
- Form labels for all inputs
- Keyboard navigation support

## Form Data

Contact form submissions are stored locally in browser storage for demonstration. In production, you would need to:

1. Set up a backend server (Node.js, Python Flask, PHP, etc.)
2. Create a database to store form submissions
3. Configure email notifications
4. Implement data validation on the server side

### Testing Form Submissions (Browser Console)
```javascript
// View all contact form submissions
getContactSubmissions()

// Clear all submissions
clearContactSubmissions()
```

## Customization Guide

### Change Company Information
Edit the following files:
- `index.html` - Update hero section and footer
- `about.html` - Update mission, vision, and company info
- `contact.html` - Update address, email, and hours

### Update Product Catalog
Edit `assets/js/products.js`:
- Add/remove products from `productCatalog` array
- Update categories as needed
- Prices and specifications are easily editable

### Modify Colors
Edit `assets/css/style.css`:
- Update `:root` CSS variables at the top
- All colors are defined as variables for easy modification

### Change Logo
Replace `ve-logo.jpg` with your own logo image and update references in HTML files.

## Contact Information

**Vijaya Lakshmi Enterprises**

- **Address**: 3rd Floor, 346, Aristo Complex, Opp. Sanghani Skyz, Navrachna University Road, Bhayali TP-2, Vadodara-391 410
- **Email**: vijayalakshmienterprise1@gmail.com
- **Business Hours**: Monday-Friday 9:00 AM - 6:00 PM, Saturday 10:00 AM - 4:00 PM

## License

This website is created for Vijaya Lakshmi Enterprises. All rights reserved © 2024.

## Support

For questions or modifications, please contact Vijaya Lakshmi Enterprises directly at the email address provided above.

---

**Website Version**: 1.0  
**Last Updated**: April 2024  
**Created with**: HTML5, CSS3, Vanilla JavaScript
